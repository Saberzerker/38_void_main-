import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:smoodhconnect_studentapp/Screens/Start_Screen/start_screen.dart';
import 'package:smoodhconnect_studentapp/Screens/Login_Screen/login_screen.dart';
import 'package:smoodhconnect_studentapp/Screens/Assigment_Screen/assignment_screen.dart';
import 'package:smoodhconnect_studentapp/Screens/DateSheet_Screen/datesheet_screen.dart';
import 'package:smoodhconnect_studentapp/Screens/Fees_Screen/fees_screen.dart';
import 'package:smoodhconnect_studentapp/Screens/My_Profile_Screen/my_profile.dart';
import 'package:smoodhconnect_studentapp/Screens/Home_Screen/home_screen.dart';

Map<String, WidgetBuilder> routes = {
  //all screens will be registered here like manifest in android
  Splash.routeName: (context) => Splash(),
  HomeScreen.routeName: (context) => HomeScreen(),
  MyProfileScreen.routeName: (context) => MyProfileScreen(),
  FeeScreen.routeName: (context) => FeeScreen(),
  AssignmentScreen.routeName: (context) => AssignmentScreen(),
  DateSheetScreen.routeName: (context) => DateSheetScreen(),
};
