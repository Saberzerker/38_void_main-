import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:smoodhconnect_studentapp/routes.dart';
import 'package:smoodhconnect_studentapp/theme.dart';
import 'package:smoodhconnect_studentapp/Screens/Start_Screen/start_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Sizer(builder: (context, orientation, device) {
      return MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Smoodh Connect',
        theme: CustomTheme().baseTheme,
        initialRoute: Splash.routeName,
        routes: routes,
      );
    });
  }
}
