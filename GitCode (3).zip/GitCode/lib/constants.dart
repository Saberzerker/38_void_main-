import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

//Hex/#code of colors to ARGB values
Color hexToColor(String hexString, {String alphaChannel = 'FF'}) {
  return Color(int.parse(hexString.replaceFirst('#', '0x$alphaChannel')));
}

//colors
Color primaryColorA = hexToColor('#C0B1F1');
Color secondaryColor = hexToColor('#332B65');
Color textDark = hexToColor('#120718');
Color containerColor = hexToColor('#FFB3BC');
Color textLight = hexToColor('#F2FFAD');
Color errorBorderColor = const Color(0xFFE74C3C);

//default value
const kDefaultPadding = 20.0;

const sizedBox = SizedBox(
  height: kDefaultPadding,
);
const kWidthSizedBox = SizedBox(
  width: kDefaultPadding,
);

const kHalfSizedBox = SizedBox(
  height: kDefaultPadding / 2,
);

const kHalfWidthSizedBox = SizedBox(
  width: kDefaultPadding / 2,
);

final kTopBorderRadius = BorderRadius.only(
  topLeft: Radius.circular(SizerUtil.deviceType == DeviceType.tablet ? 40 : 20),
  topRight:
      Radius.circular(SizerUtil.deviceType == DeviceType.tablet ? 40 : 20),
);

final kBottomBorderRadius = BorderRadius.only(
  bottomRight:
      Radius.circular(SizerUtil.deviceType == DeviceType.tablet ? 40 : 20),
  bottomLeft:
      Radius.circular(SizerUtil.deviceType == DeviceType.tablet ? 40 : 20),
);

//TextSyles
final textStyle1 = GoogleFonts.openSans(
    color: textDark, fontWeight: FontWeight.w800, fontSize: 20);

final textStyle2 = GoogleFonts.openSans(
    color: textLight, fontWeight: FontWeight.w800, fontSize: 20);

final textStyle3 = GoogleFonts.openSans(
    color: textDark, fontWeight: FontWeight.w400, fontSize: 14);
