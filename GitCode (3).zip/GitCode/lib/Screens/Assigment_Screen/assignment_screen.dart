import 'package:smoodhconnect_studentapp/constants.dart';
import 'package:smoodhconnect_studentapp/Screens/Assigment_Screen/assignment_data/assignment_data.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:smoodhconnect_studentapp/Screens/Assigment_Screen/assignment_widgets/assignment_widget.dart';

class AssignmentScreen extends StatelessWidget {
  const AssignmentScreen({Key? key}) : super(key: key);
  static String routeName = 'AssignmentScreen';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        // appBar: AppBar(
        //   title: Text('Assignments'),
        // ),
        // body: Column(
        //   children: [
        //     Expanded(
        //       child: Container(
        //         decoration: BoxDecoration(
        //           color: containerColor,
        //           borderRadius: kTopBorderRadius,
        //         ),
        //         child: ListView.builder(
        //             padding: EdgeInsets.all(kDefaultPadding),
        //             itemCount: assignment.length,
        //             itemBuilder: (context, int index) {
        //               return Container(
        //                 margin: EdgeInsets.only(bottom: kDefaultPadding),
        //                 child: Column(
        //                   mainAxisAlignment: MainAxisAlignment.center,
        //                   children: [
        //                     Container(
        //                       padding: EdgeInsets.all(kDefaultPadding),
        //                       decoration: BoxDecoration(
        //                         borderRadius:
        //                             BorderRadius.circular(kDefaultPadding),
        //                         color: containerColor,
        //                         boxShadow: [
        //                           BoxShadow(
        //                             color: textLight,
        //                             blurRadius: 2.0,
        //                           ),
        //                         ],
        //                       ),
        //                       child: Column(
        //                         crossAxisAlignment: CrossAxisAlignment.start,
        //                         children: [
        //                           Container(
        //                             width: 40.w,
        //                             height: 4.h,
        //                             decoration: BoxDecoration(
        //                               color: secondaryColor.withOpacity(0.4),
        //                               borderRadius:
        //                                   BorderRadius.circular(kDefaultPadding),
        //                             ),
        //                             child: Center(
        //                               child: Text(
        //                                 assignment[index].subjectName,
        //                                 style:
        //                                     Theme.of(context).textTheme.caption,
        //                               ),
        //                             ),
        //                           ),
        //                           kHalfSizedBox,
        //                           Text(
        //                             assignment[index].topicName,
        //                             style: Theme.of(context)
        //                                 .textTheme
        //                                 .subtitle2!
        //                                 .copyWith(
        //                                   color: textDark,
        //                                   fontWeight: FontWeight.w900,
        //                                 ),
        //                           ),
        //                           kHalfSizedBox,
        //                           AssignmentDetailRow(
        //                             title: 'Assign Date',
        //                             statusValue: assignment[index].assignDate,
        //                           ),
        //                           kHalfSizedBox,
        //                           AssignmentDetailRow(
        //                             title: 'Last Date',
        //                             statusValue: assignment[index].lastDate,
        //                           ),
        //                           kHalfSizedBox,
        //                           AssignmentDetailRow(
        //                             title: 'Status',
        //                             statusValue: assignment[index].status,
        //                           ),
        //                           kHalfSizedBox,
        //                           //use condition here to display button
        //                           if (assignment[index].status == 'Pending')
        //                             //then show button
        //                             AssignmentButton(
        //                               onPress: () {
        //                                 //submit here
        //                               },
        //                               title: 'To be Submitted',
        //                             ),
        //                         ],
        //                       ),
        //                     ),
        //                   ],
        //                 ),
        //               );
        //             }),
        //       ),
        //     ),
        //   ],
        // ),
        );
  }
}
