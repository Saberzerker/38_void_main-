import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:smoodhconnect_teacherapp/constants.dart';

//Hex/#code of colors to ARGB values
Color hexToColor(String hexString, {String alphaChannel = 'FF'}) {
  return Color(int.parse(hexString.replaceFirst('#', '0x$alphaChannel')));
}

class LoginPage extends StatelessWidget {
  static String routeName = 'LoginScreen';
  final usernameController = TextEditingController();
  final passwordController = TextEditingController();

  void signUserIn() {}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryColorA,
      body: SafeArea(
        child: Center(
          child: Column(
            children: [
              const SizedBox(height: 50),

              //logo
              Image.asset(
                'lib/images/logo2.png',
                height: 125,
                width: 125,
              ),

              //SizedBox(height: 10),

              //text
              Text(
                'SIGN IN',
                style: textStyle1,
              ),
              SizedBox(height: 50),

              //text 2
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('USER ID', style: textStyle2),
                  // SizedBox(width: 50.w),
                  const SizedBox(
                    width: 165,
                  ),
                  Text('New? Sign Up', style: textStyle3),
                ],
              ),

              SizedBox(height: 10),

              //user name text field
              inputTextField(
                controller: usernameController,
                hintText: 'Username',
                obscureText: false,
              ),

              const SizedBox(height: 10),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('PASSWORD', style: textStyle2),
                  const SizedBox(
                    width: 240,
                  ),
                ],
              ),

              const SizedBox(
                height: 10,
              ),

              //password textfield
              inputTextField(
                controller: passwordController,
                hintText: 'Password',
                obscureText: true,
              ),

              //forgot password
              const SizedBox(height: 10),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 25.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text('Forgot Password', style: textStyle3),
                  ],
                ),
              ),

              SizedBox(height: 10),
              //sign in
              MyButton(
                onTap: signUserIn,
              ),

              const SizedBox(height: 30),

              // or continue with
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 25.0),
                child: Row(
                  children: [
                    Expanded(
                      child: Divider(
                        thickness: 1.0,
                        color: secondaryColor,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10.0),
                      child: Text(
                        'Or continue with',
                        style: TextStyle(color: secondaryColor),
                      ),
                    ),
                    Expanded(
                      child: Divider(
                        thickness: 1.0,
                        color: secondaryColor,
                      ),
                    ),
                  ],
                ),
              ),
              //or continut with

              //google + facebook sign in button
              SizedBox(
                height: 20,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  // google button
                  tileC(imagePath: 'lib/images/google1.png'),

                  SizedBox(width: 45),

                  // apple button
                  tileC(imagePath: 'lib/images/apple1.png')
                ],
              ),

              const SizedBox(height: 50),
            ],
          ),
        ),
      ),
    );
  }
}





          // Container(
          //   height: 100.0,
          //   width: 100.0,
          //   decoration: BoxDecoration(
          //     borderRadius: BorderRadius.all(Radius.circular(20)),
          //     color: hexToColor('#FFB38C'),
          //     image: const DecorationImage(
          //         image: AssetImage('lib/images/logo2.jpg'),
          //         alignment: Alignment.center),
          //   ),
          // ),