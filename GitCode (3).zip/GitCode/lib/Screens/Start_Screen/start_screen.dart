import 'package:smoodhconnect_studentapp/Screens/Home_Screen/home_screen.dart';
import 'package:smoodhconnect_studentapp/screens/login_screen/login_screen.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:smoodhconnect_studentapp/constants.dart';

class Splash extends StatefulWidget {
  const Splash({super.key});
  static String routeName = 'Splash';

  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  void initState() {
    super.initState();
    _navigatetohome();
  }

  _navigatetohome() async {
    await Future.delayed(Duration(seconds: 3), () {});
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => HomeScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryColorA,
      body: Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              'lib/images/logo2.png',
              height: 150,
              width: 150,
            )
          ],
        ),
      ),
    );
  }
}
