import 'package:flutter/widgets.dart';
import 'package:smoodhconnect_teacherapp/Screens/login_page.dart';
import 'package:smoodhconnect_teacherapp/Screens/signup_page.dart';

Map<String, WidgetBuilder> routes = {
  LoginPage.routeName: (context) => LoginPage(),
};
