import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
runApp(MyApp());
}

class MyApp extends StatefulWidget {
@override
_MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
List data;

Future<String> getData() async {
var response = await http.get(
Uri.parse("http://192.168.203.1:5000/")); // replace with your IP address

kotlin
Copy code
setState(() {
  var jsonData = json.decode(response.body);
  data = jsonData.values.toList();
});

return "Data fetched successfully";
}

@override
void initState() {
super.initState();
getData();
}

@override
Widget build(BuildContext context) {
return MaterialApp(
home: Scaffold(
appBar: AppBar(
title: Text("Student Fees"),
),
body: Container(
child: Center(
child: data == null
? CircularProgressIndicator()
: ListView.builder(
itemCount: data.length,
itemBuilder: (BuildContext context, int index) {
String name = jsonData.keys.toList()[index];
List<String> fees = data[index].cast<String>();
return Column(
children: [
ListTile(
title: Text(
name,
style: TextStyle(
fontWeight: FontWeight.bold, fontSize: 20),
),
trailing: Icon(Icons.arrow_forward_ios),
),
SizedBox(height: 10),
ListView.builder(
shrinkWrap: true,
physics: NeverScrollableScrollPhysics(),
itemCount: fees.length,
itemBuilder: (BuildContext context, int index) {
return Padding(
padding: EdgeInsets.symmetric(
vertical: 5, horizontal: 20),
child: Row(
mainAxisAlignment:
MainAxisAlignment.spaceBetween,
children: [
Text(
"Fee ${index + 1}:",
style: TextStyle(fontSize: 16),
),
Text(
fees[index],
style: TextStyle(fontSize: 16),
),
],
),
);
},
),
SizedBox(height: 20),
],
);
},
),
),
),
),
);
}
}