import pandas as pd
import numpy as np
from flask import Flask, jsonify

dataframe = pd.read_excel('Fees.xlsx')
names = dataframe['Name']
fee = dataframe['Fee']

app = Flask(__name__)

@app.route('/')
def diction():
    result = {}
    for i in range(len(names)):
        if names[i] not in result:
            result[names[i]] = []
        result[names[i]].append(str(fee[i]))
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True, port=5000)

