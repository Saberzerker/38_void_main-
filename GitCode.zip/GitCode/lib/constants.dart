import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

//Hex/#code of colors to ARGB values
Color hexToColor(String hexString, {String alphaChannel = 'FF'}) {
  return Color(int.parse(hexString.replaceFirst('#', '0x$alphaChannel')));
}

//colors
Color primaryColorA = hexToColor('#C0B1F1');
Color secondaryColor = hexToColor('#332B65');
Color textDark = hexToColor('#120718');
Color containerColor = hexToColor('#FFB38C');
Color textLight = hexToColor('#F2FFAD');
Color errorBorderColor = const Color(0xFFE74C3C);

//TextSyles
final textStyle1 = GoogleFonts.openSans(
    color: textDark, fontWeight: FontWeight.w800, fontSize: 20);

final textStyle2 = GoogleFonts.openSans(
    color: textLight, fontWeight: FontWeight.w800, fontSize: 20);

final textStyle3 = GoogleFonts.openSans(
    color: textDark, fontWeight: FontWeight.w800, fontSize: 16);

//Functions

//inputTextField
class inputTextField extends StatelessWidget {
  final controller;
  final String hintText;
  final bool obscureText;

  const inputTextField({
    super.key,
    required this.controller,
    required this.hintText,
    required this.obscureText,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 25.0),
      child: TextField(
        controller: controller,
        obscureText: obscureText,
        decoration: InputDecoration(
            enabledBorder: const OutlineInputBorder(
              borderSide: BorderSide(color: Colors.white),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: secondaryColor),
            ),
            fillColor: containerColor,
            filled: true,
            hintText: hintText,
            hintStyle: TextStyle(color: Colors.grey[500])),
      ),
    );
  }
}
