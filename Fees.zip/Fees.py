import pandas as pd
import flet as ft
import numpy as np

dataframe=pd.read_excel('Fees.xlsx')

names=dataframe['Name']
fee=dataframe['Fee']
print(names)

def main(page: ft.Page):
    
    
    name_check = ft.TextField(label="Enter Name",value=' ')

    index=0
    for i in range(len(names)-1):
        if (name_check)==(names[i]):
            index=i
            print(index)
            break

    def display(e):
        bs.open = True
        bs.update()

    def close_bs(e):
        bs.open = False
        bs.update()

    def retrieve(e):
        int(Fee[index])-c.value
        page.update()


    b1= ft.ElevatedButton('Enter', on_click=display)    
    c= ft.TextField(label="Enter Amt: ", value=0)
    close=ft.ElevatedButton("Close", on_click=close_bs)
    

    bs= ft.BottomSheet(ft.Container(ft.Column(
        [
            ft.Text("Unpayed Fee: "),ft.Text(fee[index]),
            c,
            ft.ElevatedButton("Confirm", on_click=retrieve),
            close
        ]
    )))
    page.overlay.append(bs)
    page.add(name_check,b1)

# End of app
ft.app(target=main)