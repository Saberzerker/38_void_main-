import pandas as pd
import flet as ft
import numpy as np


# Reading an Excel sheet
attendance_dataframe=pd.read_excel('Attendance.xlsx')
days=(len(attendance_dataframe))


# Extracting individual column datas
dates=(attendance_dataframe['Date'])
maths=attendance_dataframe['Maths']
physics=attendance_dataframe['Physics']
chemistry=attendance_dataframe['Chemistry']



# Implementing Flet
def main(page: ft.Page):

    t=ft.Text()

    # Input textfield to enter date of attendance
    date_check = ft.TextField(label="Enter Date: (yyyy-mm-dd)",value="2023-01-01")


    # Function to update attendance
    def dropdown(e):

        index=-1

        for i in range(len(dates)-1):
            if (str(date_check.value)+' 00:00:00')==str(dates[i]):
                index=i

        # Function to update Math attendance
        def maths_update(e):
            maths[index]=click.value
            page.update()

        # Function to update Physics attendance
        def physics_update(e):
            physics[index]=click.value
            page.update()

        # Function to update Chemistry attendance
        def chemistry_update(e):
            chemistry[index]=click.value
            page.update()

        # Page title and alignment
        page.title = "Attendance"
        page.vertical_alignment = ft.MainAxisAlignment.CENTER
        

        # Submit buttons
        m = ft.ElevatedButton(text='Submit', on_click=maths_update)
        c = ft.ElevatedButton(text='Submit', on_click=chemistry_update)
        p = ft.ElevatedButton(text='Submit', on_click=physics_update)

        # 1=present, 0=Absent
        click = ft.RadioGroup(content=ft.Column([
        ft.Radio(value=1, label="1"),
        ft.Radio(value=0, label="0")]))

        #Implementing the above functions in the output screen
        page.add(ft.Column([ft.Text("Maths:"), click, m, t]),
                 ft.Column([ft.Text("Physics:"), click, p, t]),
                 ft.Column([ft.Text("Chemistry:"), click, c, t])
                )



    b = ft.ElevatedButton(text="Submit", on_click=dropdown)
    page.add(date_check,b)
    
    
# End of app
ft.app(target=main)


# Updating dataframe values
attendance_dataframe['Maths']=maths
attendance_dataframe['Physics']=physics
attendance_dataframe['Chemistry']=chemistry


# Formula to calculate % attendance
maths_attendance=(round((sum(maths)/days)*100,2))
physics_attendance=(round((sum(physics)/days)*100,2))
chemistry_attendance=(round((sum(chemistry)/days)*100,2))


# Copying data to new excel sheet
attendance_dataframe.to_excel('New_Attendance.xlsx')















