import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import 'constants.dart';

class CustomTheme {
  var baseTheme = ThemeData.light().copyWith(
    scaffoldBackgroundColor: primaryColorA,
    primaryColor: primaryColorA,
    appBarTheme: AppBarTheme(
      toolbarHeight: SizerUtil.deviceType == DeviceType.tablet ? 9.h : 7.h,
      backgroundColor: primaryColorA,
      titleTextStyle: GoogleFonts.openSans(
        fontSize: SizerUtil.deviceType == DeviceType.tablet ? 12.sp : 13.sp,
        fontWeight: FontWeight.w500,
        letterSpacing: 2.0,
      ),
      iconTheme: IconThemeData(
        color: containerColor,
        size: SizerUtil.deviceType == DeviceType.tablet ? 17.sp : 18.sp,
      ),
      elevation: 2,
    ),
    //input decoration theme for all our the app
    // inputDecorationTheme: InputDecorationTheme(
    //   labelStyle: TextStyle(
    //       fontSize: 11.sp, color: textLight, fontWeight: FontWeight.w400),
    //   hintStyle: TextStyle(fontSize: 16.0, color: textDark, height: 0.5),
    //   enabledBorder: UnderlineInputBorder(
    //     borderSide: BorderSide(color: textLight, width: 0.7),
    //   ),
    //   border: UnderlineInputBorder(
    //     borderSide: BorderSide(color: textLight),
    //   ),
    //   disabledBorder: UnderlineInputBorder(
    //     borderSide: BorderSide(color: textLight),
    //   ),
    //   focusedBorder: UnderlineInputBorder(
    //     borderSide: BorderSide(
    //       color: primaryColorA,
    //     ),
    //   ),

    //   errorBorder: UnderlineInputBorder(
    //     borderSide: BorderSide(color: errorBorderColor, width: 1.2),
    //   ),
    //   focusedErrorBorder: UnderlineInputBorder(
    //     borderSide: BorderSide(
    //       color: errorBorderColor,
    //       width: 1.2,
    //     ),
    //   ),
    // ),

    textTheme: GoogleFonts.poppinsTextTheme().copyWith(
      //custom text for bodyText1
      headline5: GoogleFonts.chewy(
        color: textLight,
        //condition if device is tablet or a phone
        fontSize: SizerUtil.deviceType == DeviceType.tablet ? 45.sp : 40.sp,
      ),
      bodyText1: TextStyle(
          color: textLight, fontSize: 35.0, fontWeight: FontWeight.bold),
      bodyText2: TextStyle(
        color: textLight,
        fontSize: 28.0,
      ),
      subtitle1: TextStyle(
          color: textDark,
          fontSize: SizerUtil.deviceType == DeviceType.tablet ? 14.sp : 17.sp,
          fontWeight: FontWeight.w700),
      subtitle2: GoogleFonts.openSans(
          color: textDark,
          fontSize: SizerUtil.deviceType == DeviceType.tablet ? 12.sp : 13.sp,
          fontWeight: FontWeight.w200),
      caption: GoogleFonts.openSans(
          color: textDark,
          fontSize: SizerUtil.deviceType == DeviceType.tablet ? 5.sp : 7.sp,
          fontWeight: FontWeight.w300),
    ),
  );
}
