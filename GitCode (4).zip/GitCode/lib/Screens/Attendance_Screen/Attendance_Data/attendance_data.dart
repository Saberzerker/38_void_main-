class AttendanceData {
  final String date;
  final String subjectname;
  final String outcome;

  AttendanceData(
    this.date,
    this.subjectname,
    this.outcome,
  );
}
