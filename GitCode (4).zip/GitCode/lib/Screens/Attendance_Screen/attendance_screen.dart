import 'package:smoodhconnect_studentapp/constants.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'Attendance_Data/attendance_data.dart';

class AttendanceScreen extends StatefulWidget {
  const AttendanceScreen({Key? key}) : super(key: key);
  static String routeName = 'AttendanceScreen';
  @override
  _AttendanceAppState createState() => _AttendanceAppState();
}

class _AttendanceAppState extends State<AttendanceScreen> {
  String _data = '';

  Future<String> _fetchData() async {
    final response =
        await http.get(Uri.parse('http://localhost:5000/attendance'));
    final data = json.decode(response.body);
    return 'Maths: ${data['Maths']}%, Physics: ${data['Physics']}%, Chemistry: ${data['Chemistry']}%';
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: primaryColorA,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                onPressed: () async {
                  final data = await _fetchData();
                  setState(() {
                    _data = data;
                  });
                },
                child: Text('Get Attendance'),
              ),
              SizedBox(height: 20),
              Text(_data),
            ],
          ),
        ),
      ),
    );
  }
}
