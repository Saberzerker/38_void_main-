from flask import Flask, jsonify
import pandas as pd

app = Flask(__name__)

# Reading an Excel sheet
attendance_dataframe = pd.read_excel(r'Attendance1.xlsx')
days = len(attendance_dataframe)

# Extracting individual column datas
dates = attendance_dataframe['Date']
maths = attendance_dataframe['Maths']
physics = attendance_dataframe['Physics']
chemistry = attendance_dataframe['Chemistry']

# Route to get attendance data
@app.route('/attendance')
def get_attendance():
    maths_percent = sum(maths)*100/days
    physics_percent = sum(physics)*100/days
    chemistry_percent = sum(chemistry)*100/days
    
    return jsonify({
        'Maths': maths_percent,
        'Physics': physics_percent,
        'Chemistry': chemistry_percent
    })

if __name__ == '__main__':
    app.run(debug=True)


