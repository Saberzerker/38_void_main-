import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() => runApp(attendance());

class attendance extends StatefulWidget {
  @override
  _attendanceAppState createState() => _attendanceAppState();
}

class _attendanceAppState extends State<attendance> {
  String _data = '';

  Future<String> _fetchData() async {
    final response =
        await http.get(Uri.parse('http://localhost:5000/attendance'));
    final data = json.decode(response.body);
    return 'Maths: ${data['Maths']}%, Physics: ${data['Physics']}%, Chemistry: ${data['Chemistry']}%';
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Attendance'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                onPressed: () async {
                  final data = await _fetchData();
                  setState(() {
                    _data = data;
                  });
                },
                child: Text('Get Attendance'),
              ),
              SizedBox(height: 20),
              Text(_data),
            ],
          ),
        ),
      ),
    );
  }
}
