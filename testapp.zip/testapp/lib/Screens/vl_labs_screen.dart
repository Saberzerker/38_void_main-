import 'package:app2/constants.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class VLLabsScreen extends StatelessWidget {
  static String routeName = 'VLLabsScreen';

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }
}
